Script Odoo + Nginx + SSL
=========================
v15.0 20200616

# Requirements: Ubuntu >= 16.04

Copy all files in any directory (server, vps, PC)

1 Your domain must be mapping to IP Server before to install this Script (DNS)

Example: mydomain.com > 54.168.45.45 (Your VPS / Server IP) 

2 Check as execute program

3 Run this script as root user

4 Enter a valid domain (non-www) and email
